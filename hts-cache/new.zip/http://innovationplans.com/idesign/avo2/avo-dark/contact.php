<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>301 Moved Permanently</title>
</head><body>
<h1>Moved Permanently</h1>
<p>The document has moved <a href="https://innovationplans.com/idesign/avo2/avo-dark/contact.php">here</a>.</p>
<p>Additionally, a 301 Moved Permanently
error was encountered while trying to use an ErrorDocument to handle the request.</p>
</body></html>
